<?php 
defined('BASEPATH') or die('No direct script access allowed');

$config['date'] = array(
		'bulan' => array(
				'Januari',
				'Februari',
				'Maret',
				'April',
				'Mei',
				'Juni',
				'Juli',
				'Agustus',
				'September',
				'Oktober',
				'November',
				'Desember'
			)
	);

?>